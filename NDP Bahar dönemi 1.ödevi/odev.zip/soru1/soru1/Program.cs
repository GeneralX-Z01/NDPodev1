﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:1
**				ÖĞRENCİ ADI............:Sevda Farshidfar
**				ÖĞRENCİ NUMARASI.......:B201210602
**                         DERSİN ALINDIĞI GRUP...:1B
****************************************************************************/

using System;
using System.Collections.Generic;


namespace soru1
{
    class Program
    {
        protected void konumOlustur(int[] degerX)
        {
            Random random = new Random();
            int kosul = 0;//olusturulan konumun kontrolunde kullanılan değişken
            for (int i = 0; i < 8; i++)
            {
                do
                {
                    kosul = 0;
                    degerX[i] = random.Next(0, 8);

                    for (int j = 0; j < 8; j++)
                    {
                        if (degerX[i] == degerX[j])//olusturulan degerler için kalelerin bir birini yeme durumu kontrol edilir
                        {
                            kosul++;
                        }
                    }
                } while (kosul > 1);
            }
        }
        protected void yazdir(int koordinatX, int koordinatY, string deger)
        {
            Console.SetCursorPosition(koordinatX, koordinatY);
            Console.Write(deger);
        }
        protected void konumlandır()
        {
            Program program = new Program();
            int[] koordinatY = new int[8] { 9, 9, 9, 9, 9, 9, 9, 9 };
            int[] koordinatX = new int[8];
            program.konumOlustur(koordinatX);//degiskenler fonksiyona gönderilir ve degerler olusturulur
            program.konumOlustur(koordinatY);
            int sayac_satir = 0;
            while (sayac_satir != 8)
            {
                ConsoleKeyInfo keyinfo;
                keyinfo = Console.ReadKey();
                if(keyinfo.Key==ConsoleKey.Enter)
                {
                    program.yazdir(2 * koordinatX[sayac_satir], koordinatY[koordinatX[sayac_satir]], "K");//kaleler yerleştirilir
                    sayac_satir++;
                    program.yazdir(0, 12, "");
                }
            }
        }
        //2.sorunun çözümünde kullanılacak olan değişkenler
        protected string aranan, karakter_dizin;
        protected int ilk_deger = 0;
        public void kelimeBul1()//substring metodu olmadan arama
        {
            Console.Write("Aranılacak kelime :");//kullanıcıdan kelimeler alınır
            aranan = Console.ReadLine();
            Console.Write("Karakter dizini :");//kullanıcıdan kelimeler alınır
            karakter_dizin = Console.ReadLine();
            ilk_deger = 0;
            while ((karakter_dizin.ToLower().IndexOf(aranan.ToLower(), ilk_deger) + 1) != 0)
            {
                Console.WriteLine("kelime " + aranan + " indis: " + karakter_dizin.ToLower().IndexOf(aranan.ToLower(), ilk_deger));//bulunan kelimenin bilgileri yazdırılır
                ilk_deger = karakter_dizin.ToLower().IndexOf(aranan.ToLower(), ilk_deger) + 1;//index of komutunun her seferinde kaldığı indexten devam etmesi sağlanır
            }
        }
        protected void kelimeBul2()//substring metodu ile arama
        {
            Console.Write("Aranılacak kelime :");
            aranan = Console.ReadLine();
            Console.Write("Karakter dizini :");
            karakter_dizin = Console.ReadLine();//kullanıcıdan değerler alınır
            ilk_deger = 0;
            string alt_str;
            for (int i = 0; i < karakter_dizin.Length; i++)
            {
                alt_str = karakter_dizin.Substring(ilk_deger);//girilen deger her seferinde bulunan en son kelime indexinden
                if (alt_str.ToLower().IndexOf(aranan.ToLower()) == -1) { break; }//bulunacak kelime kalmadığı zaman döngü biter
                Console.WriteLine("kelime " + aranan + " indis: " + karakter_dizin.ToLower().IndexOf(aranan.ToLower(), ilk_deger));
                ilk_deger = ilk_deger + alt_str.ToLower().IndexOf(aranan.ToLower())+1;
            }
        }
        protected void harfBul()//
        {
            int[] harf_sayi = new int[29];
            char[] harfler = new char[29] { 'A', 'B', 'C', 'Ç', 'D', 'E', 'F', 'G', 'Ğ', 'H', 'I', 'İ', 'J', 'K', 'L', 'M', 'N', 'O', 'Ö', 'P', 'R', 'S', 'Ş', 'T', 'U', 'Ü', 'V', 'Y', 'Z' };
            Console.WriteLine("Harf sayı bulunacak metni yaz:");
            string str_ifade = "1";
            List<string> result = new List<string> { };
            while (!string.IsNullOrEmpty(str_ifade))//birden fazla satırı input almak için kullanılan döngü
            {
                str_ifade = Console.ReadLine();
                result.Add(str_ifade);
            }
            foreach (string s1 in result)
            {
                str_ifade = str_ifade + s1;//satırlar tek bir stringe dönüştürülür
            }
            string metin = str_ifade.ToUpper();
            char[] aranacak = metin.ToCharArray();
            for (int i = 0; i < harfler.Length; i++)
            {
                for (int j = 0; j < aranacak.Length; j++)
                {
                    if (harfler[i] == aranacak[j])
                    {
                        harf_sayi[i]++;//harflerin kaç kez geçtiği bulunur
                    }
                }
                Console.Write(harfler[i] + ",    sayısı: " + harf_sayi[i]);
                for (int k = 0; k < harf_sayi[i]; k++)
                {
                    Console.Write(" *");//harf sayısı kadar yıldız yazdırılır
                }
                Console.WriteLine();
            }
        }
        public void calistir_2()
        {
            Program p = new Program();
            string secim;
            Console.Write("MENU\n1-String bir degiskende, string degeri substring kullanmadan ara\n2-String bir degiskende, string degeri substring kullanarak ara\n3-Alfabenin karakterlerini bir stringde ara, kaç adet geçiyor bul ve ciz\nseciminiz:");
            secim = Console.ReadLine();
            if (secim == "1")
            {
                p.kelimeBul1();
                Console.Write("Menüye dönülsün mü?(e/h)");
                secim = Console.ReadLine();
            }
            else if (secim == "2")
            {
                kelimeBul2();
                Console.Write("Menüye dönülsün mü?(e/h)");
                secim = Console.ReadLine();
            }
            else if (secim == "3")
            {
                p.harfBul();
                Console.Write("Menüye dönülsün mü?(e/h)");
                secim = Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Yanlıs secim yaptiniz.");
                Console.ReadLine();
            }
            if(secim=="e"||secim=="E")//secim evet ise tekrar console temizlenir ve menü yazdırılır
            {
                Console.Clear();
                p.calistir_2();
            }
        }
        static void Main(string[] args)
        {
            Program program = new Program();
            for (int i = 0; i < 8; i++)//tahtayı çizdirmek için kullanılan for döngüsü
            {
                for (int j = 0; j < 8; j++)
                {
                    Console.Write("0 ");//0'lardan oluşan 8x8lik matris yazdırılır
                }
                Console.Write("  [" + (8 - i) + "]");//satirlari belirtmek için kenarda satir bilgisi yazılır
                if (i == 7)
                {
                    Console.Write("\n\nA B C D E F G H");//sütunları belirtmek için en alta sütun bilgisi yazılır
                }
                Console.WriteLine();
            }
            Console.WriteLine("\n\nDevam etmek için Enter tuşuna basın");
            program.konumlandır();
            Console.WriteLine("İkinci Soruya geçmek için Enter tuşuna basın");
            Console.ReadLine();
            Console.Clear();
            program.calistir_2();
        }
    }
}
